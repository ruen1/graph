This is a open-source reimplementation of the Telegraph writing service.

Benefits over telegra.ph:
- 128,000 character limit compared to 64,000
- No callbacks to t.me and no telemetry
- Cleans up EXIF metadata before you publish
